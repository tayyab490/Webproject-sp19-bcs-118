const data =[
    {
        id:1,
        image:"./profiles/img_1.jpg",
        title:"Wade",
        description:"Physician",
        category:"Physician",
       
    },
    {
        id:2,
        image:"./profiles/img_2.jpg",
        title:"Dave",
        description:"Psychiatrist",
        category:"Psychiatrist",
       
    },
    {
        id:3,
        image:"./profiles/img_3.jpg",
        title:"Emma",
        description:"Neurologist",
        category:"Neurologist",
       
    },
    {
        id:4,
        image:"./profiles/img_4.jpg",
        title:"Riley",
        description:"Cardiologist",
        category:"Cardiologist",
       
    },
    {
        id:5,
        image:"./profiles/img_5.jpg",
        title:"Gilbert",
        description:"Physician",
        category:"Physician",
       
    },
    {
        id:6,
        image:"./profiles/img_6.jpg",
        title:"Jorge",
        description:"Radiologist",
        category:"Radiologist",
       
    },
    {
        id:7,
        image:"./profiles/img_7.jpg",
        title:"Dan",
        description:"Cardiologist",
        category:"Cardiologist",
       
    },
    {
        id:8,
        image:"./profiles/img_1.jpg",
        title:"John",
        description:"Radiologist",
        category:"Radiologist",
       
    },
    // {
    //     id:9,
    //     image:"./images/img_2.jpg",
    //     title:"SQL Tutorial",
    //     description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
    //     category:"database",
       
    // },
    // {
    //     id:10,
    //     image:"./images/img_3.jpg",
    //     title:"Mongo DB Tutorial",
    //     description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
    //     category:"database",
       
    // },
    // {
    //     id:11,
    //     image:"./images/c.jpg",
    //     title:"C Tutorial",
    //     description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
    //     category:"programming",
       
    // },
    // {
    //     id:12,
    //     image:"./images/c-plus.jpg",
    //     title:"C++ Tutorial",
    //     description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
    //     category:"programming",
       
    // },
    // {
    //     id:13,
    //     image:"./images/java.jpg",
    //     title:"Java Tutorial",
    //     description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
    //     category:"programming",
       
    // },
    // {
    //     id:14,
    //     image:"./images/python.jpg",
    //     title:"Python Tutorial",
    //     description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
    //     category:"programming",
       
    // },
    // {
    //     id:15,
    //     image:"./images/go.jpg",
    //     title:"Go Tutorial",
    //     description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    //     category:"programming",
       
    // },
]
export default data;