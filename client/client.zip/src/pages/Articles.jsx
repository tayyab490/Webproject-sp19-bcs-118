import React from 'react'

const Articles = () => {
  return (
    <div>Articles</div>
  )
}

export default Articles