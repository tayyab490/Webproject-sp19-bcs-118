import React from 'react'

// import './Mission.css'

const Mission = () => {
  return (
    <>
      <h1>mission</h1>
    </>
  )
}

export default Mission