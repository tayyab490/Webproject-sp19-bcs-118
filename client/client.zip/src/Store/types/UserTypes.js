export const SET_LOADER = 'SET_LOADER';
export const CLOSE_LOADER = 'CLOSE_LOADER';
export const SET_TOKEN = 'SET_TOKEN';
export const REGISTER_ERRORS = 'REGISTER_ERRORS';
export const LOGOUT = 'LOGOUT';
export const LOGIN_ERRORS = 'LOGIN_ERRORS';