const express = require("express");
const bodyparser = require("body-parser")
const connect = require("./config/db");
const router = require("./routes/userRoutes");
const { route } = require("./routes/userRoutes");

require('dotenv').config()
const app = express();

connect();

app.use(bodyparser.json());

app.use("/", router);
const PORT = process.env.PORT || 5000
app.listen(PORT, () => {
    console.log('App is running.');
});
